export { LeftSidebar as Chat } from './chat/components/LeftSidebar';
export { RightSidebar as Inventory } from './inventory/components/RightSidebar';
export { default as Minimap } from './minimap/components/Minimap';
export { default as Navigation } from './navigation/components/Navigation';